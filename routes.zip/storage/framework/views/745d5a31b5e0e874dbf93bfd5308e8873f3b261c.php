<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <!-- Success Message -->
  
<div class="row justify-content-center">
  <div class="col-md-4">
      <img class="img-profile" src="https://pwco.com.sg/wp-content/uploads/Generic-Profile-Placeholder-v3.png" alt="no-image">
  </div>
  <div class="offset-md-2 col-md-6">
      <div class="content">
        <!-- Data User -->
      <label for="">Name</label>
      <p><?php echo e(Auth::user()->name); ?></p>
      <label for="">Email</label>
      <p><?php echo e(Auth::user()->email); ?></p>
      <label for="">Address</label>
      <p><?php echo e(Auth::user()->address); ?></p>
      <label for="">Phone Number</label>
      <p><?php echo e(Auth::user()->phone); ?></p>
      <!-- TopUp -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ecommerce PBO\ecommerce\resources\views/home.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <!-- Styles -->
   <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
  </head>
  <body>
    <div class="container">
      <div class="login-wrapper">
        <h1 class="title">Login</h1>
        <hr>
        <form method="POST" action="<?php echo e(route('login')); ?>" class="login-form">
          <?php echo csrf_field(); ?>
          <input type="text" placeholder="E-mail" <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> name="email" value="<?php echo e(old('email')); ?>" required autofocus>

          <?php if($errors->has('email')): ?>
             <span class="invalid-feedback" role="alert">
                 <strong><?php echo e($errors->first('email')); ?></strong>
             </span>
         <?php endif; ?>

          <input type="password" placeholder="Password" <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> name="password" required>

          <?php if($errors->has('password')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('password')); ?></strong>
          </span>
        <?php endif; ?>

          <button type="submit">Login</button>
          <p class="message">Not registered? <a href="/register">Create an account</a></p>
        </form>
      </div>
    </div>
    <!-- Scripts -->
   <script src="<?php echo e(asset('js/app.js')); ?>"></script>
  </body>
</html>
<?php /**PATH E:\ecommerce PBO\ecommerce\resources\views/auth/login.blade.php ENDPATH**/ ?>
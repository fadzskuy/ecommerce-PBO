<?php $__env->startSection('title'); ?>
    Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/shop.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="category">
          <h2 id="category-label">Categories</h2>
          <ul class="list-group">
            <li class="list-group-item active">All</li>
            <li class="list-group-item"> <a href="">Pria</a></li>
            <li class="list-group-item"> <a href="">Wanita</a></li>
          </ul>
        </div>
        <h2 id="category-label" class="text-center mt-5">Search Product</h2>
        <form action="" class="form-inline ml-5">
          <input type="text" class="form-control" name="search">
          <button class="btn btn-primary">Search</button>
        </form>
      </div>
        <div class="col-lg-8">
          <div class="item-list">
          <h2>Our Products</h2>
          <hr style="margin-bottom: 2em;">
          <div class="row list-product">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 item">
              <a href="/shop/detail/<?php echo e($product->id); ?>">
              <img src="<?php echo e($product->image); ?>" alt="nopic" height="180" width="180">
              </a>
              <p class="product-name mt-3 font-weight-bold"><a href="/shop/detail"><?php echo e($product->name); ?></a></p>
              <p class="product-price">Rp. <?php echo e($product->price); ?></p>
              <br>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($products->links()); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Pagination Link -->
  
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecommerce PBO\ecommerce\resources\views/shop/index.blade.php ENDPATH**/ ?>